using MelonLoader;
using UnityEngine;

[assembly: MelonInfo(typeof(FusionRedMenu.FusionRedMenuMod), "Fusion Red Menu", "0.1.0", "OpenAI")]
[assembly: MelonGame("Stress Level Zero", "BONELAB")]

namespace FusionRedMenu
{
    // UI/config prototype. It intentionally does not change player physics,
    // other players, Fusion networking, or game state.
    public class FusionRedMenuMod : MelonMod
    {
        private bool _visible = true;
        private bool _speedOption;
        private bool _jumpOption;
        private bool _cosmeticOption = true;
        private float _speedScale = 1.0f;
        private float _jumpScale = 1.0f;
        private int _tab;
        private Rect _window = new Rect(35, 35, 390, 430);
        private GUIStyle _titleStyle;
        private GUIStyle _headerStyle;
        private GUIStyle _bodyStyle;
        private bool _stylesReady;

        public override void OnInitializeMelon()
        {
            LoggerInstance.Msg("Fusion Red Menu loaded. Press F8 to show/hide the prototype UI.");
        }

        public override void OnUpdate()
        {
            // Keyboard toggle is useful for development on a PC.
            // Quest controller input will be added in a later XR-specific pass.
            if (Input.GetKeyDown(KeyCode.F8))
                _visible = !_visible;
        }

        public override void OnGUI()
        {
            if (!_visible) return;
            EnsureStyles();
            _window = GUI.Window(72831, _window, DrawWindow, GUIContent.none);
        }

        private void EnsureStyles()
        {
            if (_stylesReady) return;

            _titleStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = 22,
                fontStyle = FontStyle.Bold,
                normal = { textColor = new Color(1f, 0.22f, 0.25f) }
            };
            _headerStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = 15,
                fontStyle = FontStyle.Bold,
                normal = { textColor = Color.white }
            };
            _bodyStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = 12,
                normal = { textColor = new Color(0.82f, 0.82f, 0.86f) }
            };
            _stylesReady = true;
        }

        private void DrawWindow(int id)
        {
            GUI.color = new Color(0.055f, 0.055f, 0.075f, 0.98f);
            GUI.Box(new Rect(0, 0, _window.width, _window.height), GUIContent.none);
            GUI.color = Color.white;

            GUI.Label(new Rect(18, 12, 340, 30), "FUSION RED MENU", _titleStyle);
            GUI.Label(new Rect(20, 42, 330, 20), "BONELAB • Quest UI prototype", _bodyStyle);
            GUI.color = new Color(0.85f, 0.08f, 0.12f);
            GUI.Box(new Rect(16, 68, _window.width - 32, 3), GUIContent.none);
            GUI.color = Color.white;

            if (GUI.Button(new Rect(_window.width - 35, 12, 22, 22), "X"))
                _visible = false;

            string[] tabs = { "PLAYER", "MOVEMENT", "COSMETICS", "ABOUT" };
            for (int i = 0; i < tabs.Length; i++)
            {
                if (GUI.Button(new Rect(16 + i * 89, 82, 85, 28), tabs[i]))
                    _tab = i;
            }

            GUI.Label(new Rect(20, 122, 340, 24), tabs[_tab], _headerStyle);
            GUI.color = new Color(0.85f, 0.08f, 0.12f);
            GUI.Box(new Rect(20, 148, 70, 2), GUIContent.none);
            GUI.color = Color.white;

            switch (_tab)
            {
                case 0:
                    GUI.Label(new Rect(22, 166, 330, 24), "Local profile panel placeholder", _bodyStyle);
                    GUI.Label(new Rect(22, 194, 330, 24), "Fusion lobby/player data is not connected yet.", _bodyStyle);
                    break;

                case 1:
                    GUI.Label(new Rect(22, 166, 330, 22), "Speed setting (UI only)", _bodyStyle);
                    _speedOption = GUI.Toggle(new Rect(22, 192, 320, 24), _speedOption, "Enable speed option");
                    _speedScale = GUI.HorizontalSlider(new Rect(22, 230, 300, 18), _speedScale, 0.5f, 2.0f);
                    GUI.Label(new Rect(22, 250, 300, 22), "Scale: " + _speedScale.ToString("0.00"), _bodyStyle);

                    GUI.Label(new Rect(22, 286, 330, 22), "Jump setting (UI only)", _bodyStyle);
                    _jumpOption = GUI.Toggle(new Rect(22, 312, 320, 24), _jumpOption, "Enable jump option");
                    _jumpScale = GUI.HorizontalSlider(new Rect(22, 350, 300, 18), _jumpScale, 0.5f, 2.0f);
                    GUI.Label(new Rect(22, 370, 300, 22), "Scale: " + _jumpScale.ToString("0.00"), _bodyStyle);
                    break;

                case 2:
                    _cosmeticOption = GUI.Toggle(new Rect(22, 170, 320, 24), _cosmeticOption, "Enable menu cosmetic theme");
                    GUI.Label(new Rect(22, 205, 330, 42), "Cosmetic controls are local UI placeholders. No other player's avatar is modified.", _bodyStyle);
                    break;

                case 3:
                    GUI.Label(new Rect(22, 168, 340, 22), "FUSION RED MENU v0.1.0", _bodyStyle);
                    GUI.Label(new Rect(22, 196, 340, 48), "Standalone Quest / LemonLoader prototype.", _bodyStyle);
                    GUI.Label(new Rect(22, 248, 340, 60), "This first build only tests the menu shell. It does not yet have Quest controller input or live Fusion APIs.", _bodyStyle);
                    break;
            }

            GUI.color = new Color(0.85f, 0.08f, 0.12f);
            GUI.Box(new Rect(16, _window.height - 42, _window.width - 32, 2), GUIContent.none);
            GUI.color = Color.white;
            GUI.Label(new Rect(20, _window.height - 32, 330, 20), "F8 = toggle on PC • Drag the top bar to move", _bodyStyle);

            GUI.DragWindow(new Rect(0, 0, _window.width, 68));
        }
    }
}
